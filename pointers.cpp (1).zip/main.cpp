#include <iostream>

using namespace std;
/// 


// int main()
// {
//   int a=10;
//   int*aptr=&a;
   
//   cout<<*aptr<<endl;
   
//   *aptr=35;
//   cout<<a<<endl;
   
///  


// int arr[]={10,20,30};

// cout<<*arr<<endl;

// int *ptr=arr;
// for(int i=0;i<3;i++){
//     cout<<*(arr+i)<<endl;
//     //arr++;// ELLEGAL
// }

///   


void swap(int *a,int *b){
    
    int temp=*a;
    *a=*b;
    *b=temp;
    
    
    
    
    
}
int main(){
    
    int a=2;
    int b=9;
    
    int*aptr=&a;
     int*bptr=&b;
     
    swap(&a,&b);
    
    cout<<a<<" "<<b<<endl;
    
    
    
    
    return 0;
    
    
    
    
}














































//     return 0;
// }
